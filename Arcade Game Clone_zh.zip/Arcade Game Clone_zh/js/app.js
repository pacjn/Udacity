// 敌人 
var Enemy = function(speed) {
    //初始化速度
    this.speed=speed;
    this.sprite = 'images/enemy-bug.png';
    //起始x位置
    this.x=-50;
    //起始y位置随机
    this.y=Math.floor((Math.random() * 3) )*80+60;
};

// 此为游戏必须的函数，用来更新敌人的位置
// 参数: dt ，表示时间间隙
Enemy.prototype.update = function(dt) {
    // 你应该给每一次的移动都乘以 dt 参数，以此来保证游戏在所有的电脑上
    // 都是以同样的速度运行的
    this.x += this.speed*dt;
    if(this.x > 600) {
        this.x=-50;
        this.y=Math.floor((Math.random() * 3) )*80+60;
    }
};

// 此为游戏必须的函数，用来在屏幕上画出敌人，
Enemy.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};

// 现在实现你自己的玩家类
// 这个类需要一个 update() 函数， render() 函数和一个 handleInput()函数
var Player = function() {
    //起始状态
    this.sprite = 'images/char-boy.png';
    this.x=200;
    this.y=380;
    this.heart=3;
    this.score=0;
    //储存一个人物图像数组，用于升级
    this.characters=[
    'images/char-boy.png',
    'images/char-cat-girl.png',
    'images/char-horn-girl.png',
    'images/char-pink-girl.png',
    'images/char-princess-girl.png'];
};

Player.prototype.update = function(enemy) {
    //用于处理碰撞，每当碰撞了heart-1 当heart<=0时 score清理，heart回到3 回到起始状态
    if (this.x<=enemy.x+80 && this.x>enemy.x-80){
        if (this.y==enemy.y){
            this.x=200;
            this.y=380;
            this.heart-=1;      
            if (this.heart<=0){
                this.sprite=this.characters[0]; 
                this.score=0;
                this.heart=3;
            }      
        }
    }
    return (this.heart);
};
Player.prototype.render = function() {    
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};
Player.prototype.handleInput = function(key) {    
    //用于控制人物移动
    if(key == 'left' && this.x >= 100){
        this.x -= 100;
    }
    if(key == 'right' && this.x < 400){
        this.x += 100;
    }
    if(key == 'up' && this.y > 0){
        this.y -= 80;
    }
    if(key == 'down' && this.y < 380){
        this.y += 80;
    }
    if(this.y < 0){
        this.x=200;
        this.y=380;
    }
};

Player.prototype.upgrade = function(score) {  
    //用于计分
    this.score=this.score+score;
    //每5分升级 更换人物图案
    this.sprite=this.characters[Math.floor(this.score/5)%5];    
    return (this.score);
};

// 星星
var Star = function() {
    this.sprite = 'images/Star.png';
    this.time_count = 0;
    this.x_arr=[0,100,200,300,400];
    this.y_arr=[60,140,220];
    this.x=this.x_arr[Math.floor((Math.random() * 5))];
    this.y=this.y_arr[Math.floor((Math.random() * 3))];
    this.score=0;
};

// 此为游戏必须的函数，用来更新宝石的位置
// 参数: dt ，表示时间间隙
Star.prototype.update = function(dt,player) {
    // 触碰到星星得分并重置星星位置
    // 每隔固定时间更新星星位置
    this.score=0;
    if (this.x==player.x && this.y==player.y){
        this.x=this.x_arr[Math.floor((Math.random() * 5))];
        this.y=this.y_arr[Math.floor((Math.random() * 3))];
        this.score=1;
        this.time_count=0;
    }
    if (this.time_count%100==0){
        this.x=this.x_arr[Math.floor((Math.random() * 5))];
        this.y=this.y_arr[Math.floor((Math.random() * 3))];
    }
    this.time_count += 1; 
    return(this.score);    
};

// 此为游戏必须的函数，用来在屏幕上画出星星
Star.prototype.render = function() {
    ctx.drawImage(Resources.get(this.sprite), this.x, this.y);
};
// 现在实例化你的所有对象
// 把所有敌人的对象都放进一个叫 allEnemies 的数组里面
// 把玩家对象放进一个叫 player 的变量里面
// 所有星星对象在allStars的数组中
var allEnemies = [];
for (var i=0; i<3; i++){
    var bug = new Enemy(i*90+60);
    allEnemies.push(bug);
}
var player = new Player(); 

var allStars=[];
for (var i=0; i<2; i++){
    var star = new Star();
    allStars.push(star);
}

// 这段代码监听游戏玩家的键盘点击事件并且代表将按键的关键数字送到 Play.handleInput()
// 方法里面。你不需要再更改这段代码了。
document.addEventListener('keyup', function(e) {
    var allowedKeys = {
        37: 'left',
        38: 'up',
        39: 'right',
        40: 'down'
    };

    player.handleInput(allowedKeys[e.keyCode]);
});
