
Neighborhood Map Program for P3
===============================

# Introduction  
This is a web to record your favorite areas and provide some information about them.

# Functions
## Get detail of area
- 5 favorite areas built-in 
- When click the name of area, its marker will display in the map
- The StreetView and relative content in Wikipedia will be shown
## Add a new area
- A new area can be searched and approximate results will be listed
- When click the add button, it will be added into the favorite area list, but the the maxium number of list is set to 6
- After a new area is added, the area will be centered in the map and its detail will be shown
## Delete an area
- A area in the list can be deleted by clicking the delete icon in the right side of the name
## Filter areas within some condition
- After time, transposrt method and target place be given, the areas in the list will be filtered
- Marker of the chosen area will be shown in the map
- Click the view route button and the route between destination and origin will display

## Find nearby places
- Search and label the nearby requested places within the bound of the map
- Click the marker in the map, the detail of the place will display
